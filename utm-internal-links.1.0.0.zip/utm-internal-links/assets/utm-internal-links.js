/**
 * UTM Internal Links — Frontend Script
 * Adiciona parâmetros UTM nos links internos no momento do clique.
 * O HTML permanece limpo para o Googlebot.
 */
(function () {
    'use strict';

    if (typeof UIL_Config === 'undefined') return;

    var cfg = UIL_Config;
    var homeUrl = (cfg.home_url || '').replace(/\/$/, '');
    var currentHost = window.location.hostname;

    function isInternal(href) {
        if (!href || href === '#' || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return false;
        try {
            var url = new URL(href, window.location.href);
            return url.hostname === currentHost;
        } catch (e) {
            return false;
        }
    }

    function addUtms(href) {
        try {
            var url = new URL(href, window.location.href);

            // Não sobrescreve UTMs já existentes no link
            if (url.searchParams.has('utm_source')) return href;

            if (cfg.utm_source)   url.searchParams.set('utm_source',   cfg.utm_source);
            if (cfg.utm_medium)   url.searchParams.set('utm_medium',   cfg.utm_medium);
            if (cfg.utm_campaign) url.searchParams.set('utm_campaign', cfg.utm_campaign);

            return url.toString();
        } catch (e) {
            return href;
        }
    }

    function getLinkText(el) {
        var text = el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '';
        return text.trim()
            .toLowerCase()
            .replace(/\s+/g, '-')
            .replace(/[^a-z0-9\-\u00C0-\u024F]/g, '')
            .substring(0, 50);
    }

    function handleClick(e) {
        var link = e.currentTarget;
        var href = link.getAttribute('href');

        if (!isInternal(href)) return;

        try {
            var url = new URL(href, window.location.href);

            if (url.searchParams.has('utm_source')) return;

            if (cfg.utm_source)   url.searchParams.set('utm_source',   cfg.utm_source);
            if (cfg.utm_medium)   url.searchParams.set('utm_medium',   cfg.utm_medium);
            if (cfg.utm_campaign) url.searchParams.set('utm_campaign', cfg.utm_campaign);

            // utm_content: usa o valor fixo do painel, ou o texto do link
            var content = cfg.utm_content || getLinkText(link);
            if (content) url.searchParams.set('utm_content', content);

            var newHref = url.toString();

            if (newHref !== href) {
                e.preventDefault();

                // Respeita target="_blank"
                if (link.target === '_blank') {
                    window.open(newHref, '_blank', 'noopener,noreferrer');
                } else {
                    window.location.href = newHref;
                }
            }
        } catch (err) {
            // Se algo der errado, navega normalmente
        }
    }

    function attachListeners() {
        var links = document.querySelectorAll('a[href]');
        links.forEach(function (link) {
            if (isInternal(link.getAttribute('href'))) {
                link.removeEventListener('click', handleClick);
                link.addEventListener('click', handleClick);
            }
        });
    }

    // Inicializa após carregamento do DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attachListeners);
    } else {
        attachListeners();
    }

    // Re-aplica para links adicionados dinamicamente (ex: menus AJAX, infinite scroll)
    if (typeof MutationObserver !== 'undefined') {
        var observer = new MutationObserver(function (mutations) {
            var hasNewLinks = false;
            mutations.forEach(function (m) {
                m.addedNodes.forEach(function (node) {
                    if (node.nodeType === 1 && (node.tagName === 'A' || node.querySelector('a'))) {
                        hasNewLinks = true;
                    }
                });
            });
            if (hasNewLinks) attachListeners();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

})();
