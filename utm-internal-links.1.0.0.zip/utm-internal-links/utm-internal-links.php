<?php
/**
 * Plugin Name: UTM Internal Links
 * Plugin URI:  https://www.linkedin.com/in/anderson-porangaba
 * Description: Automatically appends UTM parameters to all internal links via JavaScript, keeping your HTML clean for Googlebots while enabling full click tracking in GA4.
 * Version:     1.0.0
 * Author:      Anderson Porangaba
 * Author URI:  https://www.linkedin.com/in/anderson-porangaba
 * License:     GPL2
 * Text Domain: utm-internal-links
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'UIL_VERSION', '1.0.0' );
define( 'UIL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'UIL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

function uil_defaults() {
    return array(
        'utm_source'   => 'site',
        'utm_medium'   => 'internal',
        'utm_campaign' => 'navegacao',
        'utm_content'  => '',
        'enabled'      => '1',
    );
}

add_action( 'wp_enqueue_scripts', 'uil_enqueue_script' );
function uil_enqueue_script() {
    $options = wp_parse_args( get_option( 'uil_settings', array() ), uil_defaults() );
    if ( empty( $options['enabled'] ) ) return;
    wp_enqueue_script( 'utm-internal-links', UIL_PLUGIN_URL . 'assets/utm-internal-links.js', array(), UIL_VERSION, true );
    wp_localize_script( 'utm-internal-links', 'UIL_Config', array(
        'home_url'     => home_url(),
        'utm_source'   => sanitize_text_field( $options['utm_source'] ),
        'utm_medium'   => sanitize_text_field( $options['utm_medium'] ),
        'utm_campaign' => sanitize_text_field( $options['utm_campaign'] ),
        'utm_content'  => sanitize_text_field( $options['utm_content'] ),
    ) );
}

add_action( 'admin_menu', 'uil_admin_menu' );
function uil_admin_menu() {
    add_options_page( 'UTM Internal Links', 'UTM Internal Links', 'manage_options', 'utm-internal-links', 'uil_settings_page' );
}

add_action( 'admin_init', 'uil_register_settings' );
function uil_register_settings() {
    register_setting( 'uil_settings_group', 'uil_settings', 'uil_sanitize_settings' );
}

function uil_sanitize_settings( $input ) {
    return array(
        'utm_source'   => sanitize_text_field( isset( $input['utm_source'] )   ? $input['utm_source']   : '' ),
        'utm_medium'   => sanitize_text_field( isset( $input['utm_medium'] )   ? $input['utm_medium']   : '' ),
        'utm_campaign' => sanitize_text_field( isset( $input['utm_campaign'] ) ? $input['utm_campaign'] : '' ),
        'utm_content'  => sanitize_text_field( isset( $input['utm_content'] )  ? $input['utm_content']  : '' ),
        'enabled'      => isset( $input['enabled'] ) ? '1' : '0',
    );
}

add_action( 'admin_enqueue_scripts', 'uil_admin_styles' );
function uil_admin_styles( $hook ) {
    if ( $hook !== 'settings_page_utm-internal-links' ) return;
    wp_enqueue_style( 'utm-internal-links-admin', UIL_PLUGIN_URL . 'assets/admin.css', array(), UIL_VERSION );
}

function uil_settings_page() {
    $opts     = wp_parse_args( get_option( 'uil_settings', array() ), uil_defaults() );
    $home_js  = esc_js( home_url() );
    $home_esc = esc_url( home_url( '/' ) );
    $source   = esc_attr( $opts['utm_source'] );
    $medium   = esc_attr( $opts['utm_medium'] );
    $campaign = esc_attr( $opts['utm_campaign'] );
    $ucontent = esc_attr( $opts['utm_content'] );
    $enabled  = $opts['enabled'];
?>
<div class="wrap uil-wrap">

    <div class="uil-header">
        <div class="uil-header__icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
            </svg>
        </div>
        <div>
            <h1 class="uil-header__title">UTM Internal Links</h1>
            <p class="uil-header__sub">UTM parameters applied via JavaScript &mdash; clean HTML for Googlebots, full tracking for GA4.</p>
        </div>
    </div>

    <?php settings_errors(); ?>

    <form method="post" action="options.php">
        <?php settings_fields( 'uil_settings_group' ); ?>

        <div class="uil-card">
            <div class="uil-card__header"><h2>Status</h2></div>
            <div class="uil-card__body">
                <label class="uil-toggle">
                    <input type="checkbox" name="uil_settings[enabled]" value="1" <?php checked( $enabled, '1' ); ?> />
                    <span class="uil-toggle__track"></span>
                    <span class="uil-toggle__label">Enable plugin</span>
                </label>
            </div>
        </div>

        <div class="uil-card">
            <div class="uil-card__header">
                <h2>UTM Parameters</h2>
                <p>Set the values that will be appended to every internal link.</p>
            </div>
            <div class="uil-card__body uil-grid">

                <div class="uil-field">
                    <label for="utm_source">
                        <span class="uil-param">utm_source</span>
                        <span class="uil-hint">Traffic source</span>
                    </label>
                    <input type="text" id="utm_source" name="uil_settings[utm_source]"
                           value="<?php echo esc_attr( $source ); ?>" placeholder="e.g. site" oninput="uilUpdate()" />
                </div>

                <div class="uil-field">
                    <label for="utm_medium">
                        <span class="uil-param">utm_medium</span>
                        <span class="uil-hint">Media channel</span>
                    </label>
                    <input type="text" id="utm_medium" name="uil_settings[utm_medium]"
                           value="<?php echo esc_attr( $medium ); ?>" placeholder="e.g. internal" oninput="uilUpdate()" />
                </div>

                <div class="uil-field">
                    <label for="utm_campaign">
                        <span class="uil-param">utm_campaign</span>
                        <span class="uil-hint">Campaign name</span>
                    </label>
                    <input type="text" id="utm_campaign" name="uil_settings[utm_campaign]"
                           value="<?php echo esc_attr( $campaign ); ?>" placeholder="e.g. navigation" oninput="uilUpdate()" />
                </div>

                <div class="uil-field">
                    <label for="utm_content">
                        <span class="uil-param">utm_content</span>
                        <span class="uil-hint">Leave empty to use link anchor text automatically</span>
                    </label>
                    <input type="text" id="utm_content" name="uil_settings[utm_content]"
                           value="<?php echo esc_attr( $ucontent ); ?>" placeholder="auto (link text)" oninput="uilUpdate()" />
                </div>

            </div>
        </div>

        <div class="uil-card uil-card--preview">
            <div class="uil-card__header">
                <h2>Preview &mdash; hover over the links</h2>
                <p>Simulates how your site links will look with UTMs appended on click.</p>
            </div>
            <div class="uil-card__body">

                <div class="uil-browser">
                    <div class="uil-browser__bar">
                        <span class="uil-browser__dot uil-dot-r"></span>
                        <span class="uil-browser__dot uil-dot-y"></span>
                        <span class="uil-browser__dot uil-dot-g"></span>
                        <div class="uil-browser__address"><?php echo esc_url( $home_esc ); ?></div>
                    </div>
                    <div class="uil-browser__chrome">
                        <nav class="uil-fake-nav">
                            <a href="#" class="uil-demo-link uil-nav-link" data-slug="home" data-label="Home">Home</a>
                            <a href="#" class="uil-demo-link uil-nav-link" data-slug="blog" data-label="Blog">Blog</a>
                            <a href="#" class="uil-demo-link uil-nav-link" data-slug="about" data-label="About">About</a>
                            <a href="#" class="uil-demo-link uil-nav-link" data-slug="contact" data-label="Contact">Contact</a>
                        </nav>
                    </div>
                    <div class="uil-browser__body" id="uil-browser-body">
                        <div class="uil-fake-page">
                            <div class="uil-fake-hero">
                                <div class="uil-fake-h1"></div>
                                <div class="uil-fake-h1 uil-fake-h1--short"></div>
                                <a href="#" class="uil-demo-link uil-btn-link" data-slug="get-started" data-label="Get Started">Get Started &rarr;</a>
                            </div>
                            <div class="uil-fake-posts">
                                <div class="uil-fake-post">
                                    <div class="uil-fake-thumb"></div>
                                    <div class="uil-fake-meta"></div>
                                    <div class="uil-fake-title"></div>
                                    <div class="uil-fake-text"></div>
                                    <a href="#" class="uil-demo-link uil-cta-link" data-slug="seo-strategy-2025" data-label="Read more">Read more &rarr;</a>
                                </div>
                                <div class="uil-fake-post">
                                    <div class="uil-fake-thumb"></div>
                                    <div class="uil-fake-meta"></div>
                                    <div class="uil-fake-title"></div>
                                    <div class="uil-fake-text"></div>
                                    <a href="#" class="uil-demo-link uil-cta-link" data-slug="link-building-guide" data-label="Learn more">Learn more &rarr;</a>
                                </div>
                                <div class="uil-fake-post">
                                    <div class="uil-fake-thumb"></div>
                                    <div class="uil-fake-meta"></div>
                                    <div class="uil-fake-title"></div>
                                    <div class="uil-fake-text"></div>
                                    <a href="#" class="uil-demo-link uil-cta-link" data-slug="keyword-research" data-label="View post">View post &rarr;</a>
                                </div>
                            </div>
                        </div>

                        <div class="uil-utm-tooltip" id="uil-utm-tooltip">
                            <div class="uil-utm-tooltip__head">
                                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                                    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
                                </svg>
                                URL with UTM
                            </div>
                            <div class="uil-utm-tooltip__url" id="uil-utm-tooltip-url"></div>
                            <div class="uil-utm-tooltip__params" id="uil-utm-tooltip-params"></div>
                        </div>
                    </div>
                </div>

                <div class="uil-url-strip">
                    <span class="uil-url-strip__label">Generated URL:</span>
                    <code id="uil-full-url"></code>
                </div>

            </div>
        </div>

        <div class="uil-actions">
            <?php submit_button( 'Save Settings', 'primary', 'submit', false ); ?>
        </div>

    </form>
</div>

<script>
(function () {
    var homeUrl = '<?php echo esc_js( $home_js ); ?>';

    function getVals() {
        return {
            source:   document.getElementById('utm_source').value   || '',
            medium:   document.getElementById('utm_medium').value   || '',
            campaign: document.getElementById('utm_campaign').value || '',
            content:  document.getElementById('utm_content').value  || '',
        };
    }

    function slugify(str) {
        return (str || '').toLowerCase()
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, '-').replace(/[^\w\-]/g, '').substring(0, 50);
    }

    function buildUrl(slug, labelFallback) {
        var v   = getVals();
        var url = new URL(homeUrl.replace(/\/$/, '') + '/' + slug + '/');
        if (v.source)   url.searchParams.set('utm_source',   v.source);
        if (v.medium)   url.searchParams.set('utm_medium',   v.medium);
        if (v.campaign) url.searchParams.set('utm_campaign', v.campaign);
        var ct = v.content || slugify(labelFallback);
        if (ct) url.searchParams.set('utm_content', ct);
        return url.toString();
    }

    function escHtml(s) {
        return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    window.uilUpdate = function () {
        var first = document.querySelector('.uil-demo-link');
        if (!first) return;
        document.getElementById('uil-full-url').textContent =
            buildUrl(first.dataset.slug || 'link', first.dataset.label || 'link');
    };

    var tooltip    = document.getElementById('uil-utm-tooltip');
    var tooltipUrl = document.getElementById('uil-utm-tooltip-url');
    var tooltipPar = document.getElementById('uil-utm-tooltip-params');
    var bodyEl     = document.getElementById('uil-browser-body');

    document.querySelectorAll('.uil-demo-link').forEach(function (link) {
        link.addEventListener('mouseenter', function () {
            var slug  = this.dataset.slug  || 'link';
            var label = this.dataset.label || slug;
            var v     = getVals();
            var ct    = v.content || slugify(label);
            var full  = buildUrl(slug, label);

            tooltipUrl.textContent = full;

            var rows = '';
            if (v.source)   rows += '<span class="p-row"><span class="p-key">utm_source</span><span class="p-eq">=</span><span class="p-val">'   + escHtml(v.source)   + '</span></span>';
            if (v.medium)   rows += '<span class="p-row"><span class="p-key">utm_medium</span><span class="p-eq">=</span><span class="p-val">'   + escHtml(v.medium)   + '</span></span>';
            if (v.campaign) rows += '<span class="p-row"><span class="p-key">utm_campaign</span><span class="p-eq">=</span><span class="p-val">' + escHtml(v.campaign) + '</span></span>';
            if (ct)         rows += '<span class="p-row"><span class="p-key">utm_content</span><span class="p-eq">=</span><span class="p-val">'  + escHtml(ct)         + '</span></span>';
            tooltipPar.innerHTML = rows;

            tooltip.classList.add('is-visible');

            var rect  = this.getBoundingClientRect();
            var wrap  = bodyEl.getBoundingClientRect();
            var left  = rect.left - wrap.left;
            var top   = rect.bottom - wrap.top + 8;
            if (left + 340 > wrap.width) left = Math.max(0, wrap.width - 344);
            tooltip.style.left = left + 'px';
            tooltip.style.top  = top  + 'px';

            document.getElementById('uil-full-url').textContent = full;
        });

        link.addEventListener('mouseleave', function () {
            tooltip.classList.remove('is-visible');
        });

        link.addEventListener('click', function (e) { e.preventDefault(); });
    });

    uilUpdate();
})();
</script>
<?php
}
