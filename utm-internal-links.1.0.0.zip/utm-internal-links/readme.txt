=== UTM Internal Links ===
Contributors: andersonporangaba
Tags: utm, analytics, google-analytics, seo, internal-links
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Appends UTM parameters to all internal links via JavaScript, keeping HTML clean for Googlebots while enabling full click tracking in GA4.

== Description ==

UTM Internal Links intercepts clicks on internal links and appends UTM parameters to the URL before navigation occurs. The HTML source remains untouched, so search engine crawlers always see clean canonical URLs. UTM parameters are only added at the moment a real user clicks a link.

= Features =

* UTM parameters applied via JavaScript, invisible to Googlebots
* Works across all internal links: navigation menus, post content, widgets, and dynamically added links
* Supports utm_source, utm_medium, utm_campaign, and utm_content
* utm_content auto-fills with the link anchor text if left empty
* Does not overwrite UTM parameters already present on a link
* Handles target="_blank" links correctly
* MutationObserver support for AJAX-loaded content and infinite scroll
* Interactive admin panel with a live browser preview

= Why this matters for GA4 =

Without UTMs on internal links, GA4 cannot distinguish which specific link drove a user to a page. With this plugin, you can isolate internal traffic as its own channel, compare CTA performance using utm_content, and build internal funnels to understand which posts lead users toward conversion pages.

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the Plugins menu in WordPress.
3. Go to Settings > UTM Internal Links to configure your parameters.

== Frequently Asked Questions ==

= Will UTM parameters affect my SEO? =

No. Parameters are applied via JavaScript on click, so search engine crawlers always see the original clean URLs.

= What happens if a link already has UTM parameters? =

The plugin will not overwrite existing UTM parameters. It only appends them when none are present.

= Does it work with dynamically loaded content? =

Yes. The plugin uses MutationObserver to detect and attach listeners to links added after page load, including AJAX menus and infinite scroll.

== Changelog ==

= 1.0.0 =
* Initial release.
